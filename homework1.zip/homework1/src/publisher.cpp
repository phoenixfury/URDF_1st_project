
#include <ros/ros.h>
#include <sensor_msgs/JointState.h>

int main(int argc, char** argv) 
{
  ros::init(argc, argv, "joint");
 
 ros::NodeHandle nh;

  ros::Publisher pub = nh.advertise<sensor_msgs::JointState>("/joint_states",10);

  ros::Rate loop_rate(1);

	  sensor_msgs::JointState joint_state;
	  joint_state.name.resize(2);
	 joint_state.position.resize(2);
	joint_state.name[0]="base_to_head_link";
	joint_state.name[1]="headlink_to_head";
  while (ros::ok()) 
  {
		joint_state.header.stamp=ros::Time::now();
		joint_state.position[0]+=0.1;
		joint_state.position[1]=0;
		     
		
		  pub.publish(joint_state);
		  ros::spinOnce();
   		 loop_rate.sleep();

 
  
}
  return 0;
}
